# this allows users to enter their name and get a welcome message
# 9/15/2022
# Alexander Brinson

# this allows people to enter their name
user_name = input()

# This takes the variable and prints out a message with their name
print('Hello', user_name, 'and welcome to CS Online!')