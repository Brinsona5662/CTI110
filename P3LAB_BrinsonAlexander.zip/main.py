is_leap_year = False
   
input_year = int(input())
input_year_str = str(input_year)

year_remainder = input_year % 4
determine_century = input_year % 100
century_remainder = input_year % 400


if determine_century == 0:
    is_leap_year = True if (century_remainder == 0) else False
else:
    is_leap_year = True if (year_remainder == 0) else False

if is_leap_year == True:
    print(input_year_str + " - leap year")
else:
    print(input_year_str + " - not a leap year")