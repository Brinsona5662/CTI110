# This programs calculates gas costs for 20, 75, and 500 miles
# 9/28/2022
# CTI-110 P2LAB - Driving Costs
# Alexander brinson

# Get the gas milage per gallon
# Get the cost of gas per gallon
# Calculate gas cost for 20 miles and assign to variable1
# Calculate gas cost for 75 miles and assign to variable2
# Calculate gas cost for 500 miles and assign to variable3
# Display variables 1, 2, and 3, as floats

gasMilage = float(input())
gasCost = float(input())
Miles20 = gasMilage / 20
Miles75 = gasMilage / 75
Miles500 = gasMilage / 500
Cost20 = gasCost / Miles20
Cost75 = gasCost / Miles75
Cost500 = gasCost / Miles500

print(f'{Cost20:.2f} {Cost75:.2f} {Cost500:.2f}')